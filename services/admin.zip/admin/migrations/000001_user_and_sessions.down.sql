DROP TABLE user_sessions;

DROP TABLE users;