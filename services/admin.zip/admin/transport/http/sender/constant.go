package sender

const ConstructionsServiceBaseURL = "http://constructions_service:8080"
const GetAdminEmailURL = ConstructionsServiceBaseURL + "/admin/email"
